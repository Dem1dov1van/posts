<template>
  <header class="header">
    <div class="header__wrapper">
      <div class="header__logo">
        <svg>
          <use xlink:href="../../assets/img/icons/sprite.svg#logo"></use>
        </svg>
        <a class="cover-link" href="https://selectel.ru"></a>
      </div>
      <div class="header__contacts">
        <ul class="header__list">
          <li>
            <svg>
              <use xlink:href="../../assets/img/icons/sprite.svg#phone"></use>
            </svg>
            <p>8 800 555 06 75</p>
            <a class="cover-link" href="tel:88005550675"></a>
          </li>
          <li>
            <svg>
              <use xlink:href="../../assets/img/icons/sprite.svg#letter"></use>
            </svg>
            <p>sales@selectel.ru</p>
            <a class="cover-link" href="mailto:sales@selectel.ru"></a>
          </li>
        </ul>
      </div>
    </div>
  </header>
</template>
