<template>
  <footer class="footer">
    <div class="footer__logo">
      <img src="../../assets/img/icons/logo-white.svg" alt="logo-white" />
      <a class="cover-link" href="https://selectel.ru"></a>
    </div>
    <div class="footer__copyright">
      <p>&copy; ООО «Селектел», 2008—2022</p>
      <p>Лицензия на телематические услуги № 176267</p>
    </div>

    <nav class="footer__navigation">
      <ul>
        <li><a href="https://selectel.ru/services/dedicated/">Серверы</a></li>
        <li><a href="#">Оборудование</a></li>
        <li>
          <a href="https://kb.selectel.ru/docs/cloud/servers/about/">Облако</a>
        </li>
        <li><a href="#">Решения</a></li>
        <li><a href="#">Дата-центры</a></li>
        <li><a href="https://selectel.ru/blog">Блог</a></li>
        <li><a href="https://selectel.ru/about/company/">О компании</a></li>
        <li><a href="#">Офисы</a></li>
      </ul>
    </nav>
    <div class="footer__social-links social-links">
      <ul class="social-links__list">
        <li>
          <svg>
            <use xlink:href="../../assets/img/icons/sprite.svg#telegram-ico"></use>
          </svg>
          <a class="cover-link" href="https://telegram.org"></a>
        </li>
        <li>
          <svg>
            <use xlink:href="../../assets/img/icons/sprite.svg#vk-ico"></use>
          </svg>
          <a class="cover-link" href="https://vk.com"></a>
        </li>
        <li>
          <svg>
            <use xlink:href="../../assets/img/icons/sprite.svg#twitter-ico"></use>
          </svg>
          <a class="cover-link" href="https://twitter.com"></a>
        </li>
        <li>
          <svg class="social-links__small-ico">
            <use xlink:href="../../assets/img/icons/sprite.svg#hh-ico"></use>
          </svg>
          <a class="cover-link" href="https://hh.ru"></a>
        </li>
      </ul>
    </div>
  </footer>
</template>
